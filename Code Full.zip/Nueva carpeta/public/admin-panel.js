document.addEventListener("DOMContentLoaded", () => {
  const adminUser = localStorage.getItem("adminUser");
  if (!adminUser) {
    window.location.href = "admin-login.html";
    return;
  }

  const tabla = document.getElementById("tablaUsuarios").querySelector("tbody");
  const logoutBtn = document.getElementById("logoutBtn");

  // Función para cargar usuarios
  async function cargarUsuarios() {
    try {
      const res = await fetch("http://localhost:3000/api/admin/usuarios");
      if (!res.ok) throw new Error("Error al obtener usuarios");
      const usuarios = await res.json();

      tabla.innerHTML = ""; // Limpiar tabla
      usuarios.forEach(user => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${user.id_user}</td>
          <td>${user.nombre}</td>
          <td>${user.usuario}</td>
          <td>${user.email}</td>
          <td>${user.telefono}</td>
          <td><button class="eliminar-btn" data-id="${user.id_user}">Eliminar</button></td>
        `;
        tabla.appendChild(tr);
      });

      // Añadir evento eliminar a botones
      document.querySelectorAll(".eliminar-btn").forEach(btn => {
        btn.addEventListener("click", eliminarUsuario);
      });
    } catch (error) {
      alert(error.message);
    }
  }

  // Función para eliminar usuario
  async function eliminarUsuario(e) {
    const id = e.target.dataset.id;
    if (!confirm("¿Estás seguro de eliminar este usuario?")) return;

    try {
      const res = await fetch(`http://localhost:3000/api/admin/usuarios/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || "Error al eliminar usuario");
      }
      alert("Usuario eliminado correctamente");
      cargarUsuarios();
    } catch (error) {
      alert(error.message);
    }
  }

  // Logout
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("adminUser");
    window.location.href = "admin-login.html";
  });

  cargarUsuarios();
});
