document.getElementById("formAdminLogin").addEventListener("submit", async (e) => {
  e.preventDefault();

  const user = e.target.user.value.trim();
  const password = e.target.password.value.trim();
  const mensaje = document.getElementById("mensajeAdminLogin");

  try {
    const res = await fetch("http://localhost:3000/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user, password }),
    });
    const data = await res.json();

    if (res.ok) {
      localStorage.setItem("adminUser", data.user);
      window.location.href = "admin-panel.html";
    } else {
      mensaje.textContent = data.message || "Error en login";
    }
  } catch (error) {
    mensaje.textContent = "Error de conexión con el servidor";
  }
});
