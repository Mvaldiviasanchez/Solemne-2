// public/login.js
document.getElementById("formLogin").addEventListener("submit", async function (e) {
  e.preventDefault();

  const usuario = this.usuario.value.trim();
  const password = this.password.value.trim();
  const mensaje = document.getElementById("mensajeLogin");

  try {
    const res = await fetch("http://localhost:3000/api/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ usuario, password })
    });

    const data = await res.json();

    if (res.ok) {
  localStorage.setItem("nombre", data.nombre);
  localStorage.setItem("usuario", data.usuario);
  localStorage.setItem("email", data.email); // si lo deseas
  window.location.href = "perfil.html";
  }
 else {
      mensaje.textContent = `Error: ${data.message}`;
    }
  } catch (error) {
    mensaje.textContent = "Error al conectar con el servidor.";
    console.error(error);
  }
});
