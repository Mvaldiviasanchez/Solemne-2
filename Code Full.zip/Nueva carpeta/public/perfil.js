document.addEventListener("DOMContentLoaded", async () => {
  const nombre = localStorage.getItem("nombre");
  const usuario = localStorage.getItem("usuario");
  const email = localStorage.getItem("email");

  document.getElementById("nombreUsuario").textContent = nombre || "N/D";
  document.getElementById("usuarioLogin").textContent = usuario || "N/D";
  document.getElementById("emailUsuario").textContent = email || "N/D";

  const preview = document.getElementById("preview");
  document.getElementById("fotoInput").addEventListener("change", function () {
    const file = this.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = e => preview.src = e.target.result;
      reader.readAsDataURL(file);
    }
  });

  const contenedor = document.getElementById("listaCursos");
  const res = await fetch(`http://localhost:3000/api/cursos/${usuario}`);
  const cursos = await res.json();

  cursos.forEach(curso => {
    const div = document.createElement("div");
    div.className = "curso";
    div.dataset.nombre = curso.nombre_curso;
    div.innerHTML = `
      <p><strong>Curso:</strong> ${curso.nombre_curso}</p>
      <input type="file" class="certificado" accept=".pdf,.jpg,.png">
      <button class="subir-cert">Subir certificado</button>
      <progress value="${curso.estado === 'completado' ? 100 : 0}" max="100"></progress>
      <span class="estado">${curso.estado}</span>
    `;
    div.querySelector(".subir-cert").addEventListener("click", async () => {
      const archivo = div.querySelector(".certificado").files[0];
      const formData = new FormData();
      formData.append("certificado", archivo);
      formData.append("usuario", usuario);
      formData.append("nombre_curso", curso.nombre_curso);
      const res = await fetch("http://localhost:3000/api/cursos/subir", {
        method: "POST",
        body: formData
      });
      if (res.ok) {
        div.querySelector("progress").value = 100;
        div.querySelector(".estado").textContent = "completado";
      }
    });
    contenedor.appendChild(div);
  });
});
