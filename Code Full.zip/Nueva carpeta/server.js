const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const multer = require("multer");
const connection = require("./database");

const app = express();
const PORT = 3000;
const upload = multer({ dest: "public/certificados/" });

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// ✅ Registro de usuario
app.post("/api/registro", async (req, res) => {
  const { nombre, usuario, password, telefono, email } = req.body;
  if (!nombre || !usuario || !password || !telefono || !email) {
    return res.status(400).json({ message: "Faltan datos obligatorios" });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const sql = "INSERT INTO usuarios (nombre, usuario, password, telefono, email) VALUES (?, ?, ?, ?, ?)";

  connection.query(sql, [nombre, usuario, hashedPassword, telefono, email], (err) => {
    if (err) return res.status(500).json({ message: "Error al registrar el usuario" });
    res.status(200).json({ message: "Usuario registrado correctamente" });
  });
});

// ✅ Login de usuario
app.post("/api/login", (req, res) => {
  const { usuario, password } = req.body;

  const sql = "SELECT * FROM usuarios WHERE usuario = ?";
  connection.query(sql, [usuario], async (err, results) => {
    if (err || results.length === 0) {
      return res.status(401).json({ message: "Usuario no encontrado" });
    }

    const user = results[0];
    const match = await bcrypt.compare(password, user.password);

    if (!match) return res.status(401).json({ message: "Contraseña incorrecta" });

    res.status(200).json({
      message: "Login exitoso",
      nombre: user.nombre,
      usuario: user.usuario,
      email: user.email
    });
  });
});

// ✅ Inscripción a curso (desde perfil)
app.post("/api/cursos/inscribir", (req, res) => {
  const { usuario, nombre_curso } = req.body;
  if (!usuario || !nombre_curso) {
    return res.status(400).json({ message: "Faltan datos" });
  }

  const sql = `
    INSERT INTO cursos_usuario (id_usuario, nombre_curso)
    SELECT u.id, ? FROM usuarios u WHERE u.usuario = ?
  `;

  connection.query(sql, [nombre_curso, usuario], (err) => {
    if (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ message: "Ya estás inscrito en ese curso" });
      }
      return res.status(500).json({ message: "Error al inscribir" });
    }
    res.status(200).json({ message: "Inscripción exitosa" });
  });
});

// ✅ Obtener cursos inscritos de un usuario
app.get("/api/cursos/:usuario", (req, res) => {
  const usuario = req.params.usuario;

  const sql = `
    SELECT cu.nombre_curso, cu.estado, cu.certificado
    FROM cursos_usuario cu
    JOIN usuarios u ON u.id = cu.id_usuario
    WHERE u.usuario = ?
  `;

  connection.query(sql, [usuario], (err, results) => {
    if (err) return res.status(500).json({ message: "Error al consultar cursos" });
    res.json(results);
  });
});

// ✅ Subida de certificado y actualización de estado
app.post("/api/cursos/subir", upload.single("certificado"), (req, res) => {
  const { usuario, nombre_curso } = req.body;
  const archivo = req.file?.filename;

  if (!archivo || !usuario || !nombre_curso) {
    return res.status(400).json({ message: "Faltan datos o archivo" });
  }

  const sql = `
    UPDATE cursos_usuario cu
    JOIN usuarios u ON u.id = cu.id_usuario
    SET cu.estado = 'completado', cu.certificado = ?
    WHERE cu.nombre_curso = ? AND u.usuario = ?
  `;

  connection.query(sql, [archivo, nombre_curso, usuario], (err) => {
    if (err) return res.status(500).json({ message: "Error al guardar certificado" });
    res.status(200).json({ message: "Certificado subido correctamente" });
  });
});

// ✅ Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});