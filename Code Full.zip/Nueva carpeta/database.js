const mysql = require("mysql2");
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database: "plataforma_practicas"
});
connection.connect(err => {
  if (err) return console.error("Error MySQL:", err);
  console.log("Conectado a MySQL");
});
module.exports = connection;
